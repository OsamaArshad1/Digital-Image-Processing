DIP ASSIGNMENT#2 FA19-BCS-066

File:"fa19-bcs-066" matlab code.
File:"image_input.jpg" input image/file.
Code for Command Prompt: fa19_bcs_066('image_input.jpg')